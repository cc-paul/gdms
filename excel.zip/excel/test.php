<?php
	header( "Location: ../" );	
?>
